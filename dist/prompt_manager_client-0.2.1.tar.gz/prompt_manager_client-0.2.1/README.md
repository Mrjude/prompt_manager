# Prompt Manager - 提示词 & 知识库管理系统

统一的提示词和知识库管理平台，支持多科室、多平台的三维管理，提供 Web 管理界面和 Python 客户端 SDK。

## 项目结构

```
prompt_manager/
├── backend/                  # 后端服务
│   ├── main.py               # FastAPI 主应用（API 路由）
│   ├── database.py           # SQLite 数据库层（CRUD + 缓存）
│   ├── models.py             # Pydantic 数据模型
│   ├── requirements.txt      # Python 依赖
│   ├── start.sh              # 后端启动脚本
│   └── prompt_manager.db     # SQLite 数据库文件（自动创建）
├── frontend/
│   └── index.html            # 单页面管理界面（Vue 3）
├── client_sdk/               # 客户端 SDK
│   ├── __init__.py
│   ├── prompt_client.py      # PromptClient 类
│   └── pyproject.toml        # SDK 构建配置
├── knowledge_retriever.py    # 知识库检索模块
├── pyproject.toml            # 项目构建配置
└── start.sh                  # 一键启动脚本
```

## 功能概览

### 提示词管理

| 功能 | 说明 |
|------|------|
| 三维管理 | 科室（口腔/植发/皮肤/眼科/儿科/医美）× 平台（百度/小红书/抖音/快手/微信）× 场景 |
| 变量引擎 | 支持 `{公司}`、`{域中文}`、`{时间}`、`{轮次}` 等占位符自动解析 |
| 版本管理 | 自动版本递增，支持一键回滚到历史版本 |
| 热更新 | 修改即时生效，通过轮询或 WebSocket 推送到客户端 |

### 知识库管理

| 功能 | 说明 |
|------|------|
| 唯一索引 | 每个科室+平台组合只保留一个知识库 |
| **知识标签** | 每条知识支持标签分类：答疑、问诊、套联、流程、默认认知、额外 |
| 条目管理 | 逐条编辑、删除、新增，每页 10 条分页，支持按标签筛选 |
| 本地持久化 | 数据存储在 SQLite，自动持久化 |
| 智能检索 | 支持关键词检索（TF-IDF）和语义检索（可选），支持按知识标签筛选 |

## 快速开始

### 1. 启动服务

```bash
# 方式一：一键启动
cd prompt_manager
bash start.sh

# 方式二：手动启动
cd backend
pip install -r requirements.txt
python main.py
```

服务启动后访问：
- 管理界面：http://localhost:8900
- API 文档：http://localhost:8900/docs

### 2. 客户端 SDK 使用

#### 安装

```bash
# 方式一：本地安装
cd client_sdk
pip install -e .

# 方式二：直接复制 prompt_client.py 到项目中
```

#### 提示词相关

```python
from prompt_client import PromptClient

client = PromptClient(base_url="http://localhost:8900")

# 预加载
client.preload()

# 获取提示词内容
content = client.get_content("hair_xhs_system")

# 获取已解析变量的提示词（最常用）
prompt = client.get_resolved(
    name="hair_xhs_system",
    robot_id="9125",
    current_round=3,
    action_desc="\n回复意图：问诊、套联"
)

# 启动后台热更新（30秒轮询一次）
client.start_auto_update(interval=30)
```

#### 知识库相关（含知识标签）

```python
# 获取知识库条目列表（全部类型）
items = client.get_knowledge(department="hair", platform="xhs")
# -> ["雄激素性脱发表现为...", "米诺地尔是常用药物...", ...]

# 按知识标签类型筛选获取
qa_items = client.get_knowledge(department="hair", platform="xhs", knowledge_type="答疑")
# -> 只返回标签为"答疑"的知识条目

inquiry_items = client.get_knowledge(department="hair", platform="xhs", knowledge_type="问诊")
# -> 只返回标签为"问诊"的知识条目

connect_items = client.get_knowledge(department="hair", platform="xhs", knowledge_type="套联")
# -> 只返回标签为"套联"的知识条目

# 获取知识库详情列表（包含类型信息）
details = client.get_knowledge_detail(department="hair", platform="xhs")
# -> [{"text": "雄激素性脱发表现为...", "type": "答疑"}, 
#     {"text": "请问您脱发持续多久了？", "type": "问诊"}, ...]

# 按类型筛选详情
qa_details = client.get_knowledge_detail(department="hair", platform="xhs", knowledge_type="答疑")
# -> [{"text": "...", "type": "答疑"}, ...]

# 获取合并文本（支持按类型筛选）
text = client.get_knowledge_text(department="hair", platform="xhs")
# -> "雄激素性脱发表现为...\n米诺地尔是常用药物..."

qa_text = client.get_knowledge_text(department="hair", platform="xhs", knowledge_type="答疑", separator="\n")
# -> 只包含"答疑"类型知识的合并文本

# 获取所有知识库（支持按类型筛选）
all_kb = client.get_all_knowledge()
# -> {"hair/xhs": [...], "dentistry/bd": [...], ...}

all_qa = client.get_all_knowledge(knowledge_type="答疑")
# -> 只返回各知识库中"答疑"类型的条目

# 刷新知识库缓存
client.refresh_knowledge(department="hair", platform="xhs")

# 预加载全部（提示词 + 知识库）
client.preload()
```

### 3. 知识库检索（含知识标签筛选）

```python
from knowledge_retriever import KnowledgeRetriever

# 关键词检索（默认，无需额外依赖）
retriever = KnowledgeRetriever(base_url="http://localhost:8900")
retriever.preload(department="hair", platform="xhs")

history = [
    {"role": "user", "content": "最近掉头发很严重怎么办"},
    {"role": "assistant", "content": "请问您掉发持续多长时间了？"}
]

# 检索相关知识（全部类型）
results = retriever.retrieve(history, department="hair", platform="xhs", top_k=5)

# 按知识标签类型筛选检索
qa_results = retriever.retrieve(
    history, 
    department="hair", 
    platform="xhs", 
    top_k=5,
    knowledge_type="答疑"  # 只检索"答疑"类型的知识
)

inquiry_results = retriever.retrieve(
    history, 
    department="hair", 
    platform="xhs", 
    top_k=5,
    knowledge_type="问诊"  # 只检索"问诊"类型的知识
)

# 获取拼接文本（直接插入 prompt，支持按类型筛选）
knowledge_text = retriever.retrieve_as_text(
    history, department="hair", platform="xhs",
    top_k=5, separator="\n"
)

qa_knowledge_text = retriever.retrieve_as_text(
    history, department="hair", platform="xhs",
    top_k=5, separator="\n",
    knowledge_type="答疑"  # 只检索"答疑"类型
)
```

#### 语义检索（可选）

```bash
pip install sentence-transformers
```

```python
retriever = KnowledgeRetriever(
    base_url="http://localhost:8900",
    use_semantic=True,
    semantic_model="shibing624/text2vec-base-chinese"
)
# 使用方式与关键词检索完全相同，同样支持 knowledge_type 参数
results = retriever.retrieve(
    history, department="hair", platform="xhs", 
    top_k=5, knowledge_type="答疑"
)
```

## 知识标签类型说明

知识库中的每条知识都带有一个标签类型，用于分类管理：

| 标签类型 | 说明 | 使用场景 |
|----------|------|----------|
| **答疑** | 解答用户疑问的知识 | 回答用户关于症状、治疗、效果等问题 |
| **问诊** | 询问用户情况的知识 | 引导用户提供症状、病史等信息 |
| **套联** | 获取联系方式的话术 | 引导用户提供电话、微信等联系方式 |
| **流程** | 业务流程相关知识 | 介绍就诊流程、预约流程等 |
| **默认认知** | 基础认知类知识 | 通用常识、基础概念等 |
| **额外** | 其他补充知识 | 不属于以上分类的其他知识 |

### 知识标签使用场景

1. **按场景检索不同类型的知识**
   - 用户提问时，优先检索"答疑"类型知识
   - 需要问诊时，检索"问诊"类型知识
   - 准备套联时，检索"套联"类型知识

2. **组合使用多种类型**
   ```python
   # 分别获取不同类型的知识
   qa_text = client.get_knowledge_text("hair", "xhs", knowledge_type="答疑")
   inquiry_text = client.get_knowledge_text("hair", "xhs", knowledge_type="问诊")
   connect_text = client.get_knowledge_text("hair", "xhs", knowledge_type="套联")
   
   # 按需组合到 prompt 中
   ```

3. **智能检索时按类型筛选**
   ```python
   # 根据对话意图检索相关知识
   if "症状" in user_message:
       results = retriever.retrieve(history, "hair", "xhs", knowledge_type="答疑")
   elif "联系方式" in context:
       results = retriever.retrieve(history, "hair", "xhs", knowledge_type="套联")
   ```

## API 接口

### 提示词 API

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/prompts` | 创建提示词 |
| GET | `/api/prompts` | 列表查询（支持科室/平台/场景/关键词过滤） |
| GET | `/api/prompts/{id}` | 获取详情 |
| PUT | `/api/prompts/{id}` | 更新内容 |
| DELETE | `/api/prompts/{id}` | 删除 |
| GET | `/api/prompts/{id}/versions` | 获取版本历史 |
| POST | `/api/prompts/{id}/rollback` | 回滚到指定版本 |
| GET | `/api/v1/fetch/{name}` | 按名称获取（客户端用） |
| GET | `/api/v1/sync` | 全量同步（客户端用） |
| POST | `/api/v1/resolve` | 变量解析 |

### 知识库 API

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/knowledge` | 创建知识库（科室+平台唯一） |
| GET | `/api/knowledge` | 列表查询（支持科室/平台/关键词过滤） |
| GET | `/api/knowledge/{id}` | 获取详情 |
| PUT | `/api/knowledge/{id}` | 更新内容（JSON 数组，每项含 text 和 type） |
| DELETE | `/api/knowledge/{id}` | 删除 |
| GET | `/api/meta/kb_types` | 获取知识类型列表 |

### WebSocket

| 路径 | 说明 |
|------|------|
| `/ws/updates` | 实时推送提示词/知识库变更 |

## 科室与平台编码

| 科室代码 | 中文名 | 平台代码 | 中文名 |
|----------|--------|----------|--------|
| hair | 植发科 | xhs | 小红书 |
| dentistry | 口腔科 | bd | 百度 |
| dermatology | 皮肤科 | dy | 抖音 |
| ophthalmology | 眼科 | kuaishou | 快手 |
| pediatrics | 儿科 | wechat | 微信 |
| beauty | 医美 | general | 通用 |
| general | 通用 | | |

## 知识库数据格式

知识库内容以 JSON 数组存储，每条知识包含 `text` 和 `type` 字段：

```json
[
    {"text": "雄激素性脱发表现为头皮渐进性毛发稀疏...", "type": "答疑"},
    {"text": "请问您脱发持续多长时间了？", "type": "问诊"},
    {"text": "留下联系方式可以安排专业医生为您详细诊断", "type": "套联"},
    {"text": "米诺地尔是常用的外用药物...", "type": "答疑"}
]
```

系统会自动兼容旧格式（纯字符串数组），迁移时默认标记为"答疑"类型。

## 客户端 SDK 构建

```bash
cd client_sdk

# 构建
pip install build
python -m build

# 本地安装
pip install -e .

# 发布到 PyPI（可选）
pip install twine
twine upload dist/*
```

## 技术栈

- **后端**：FastAPI + SQLite + Pydantic
- **前端**：Vue 3（CDN）+ 单 HTML 文件
- **客户端 SDK**：纯 Python，零依赖（语义检索可选 sentence-transformers）
- **数据库**：SQLite，自动迁移
