# Prompt Manager — 提示词 / 知识库 / 流程树 一体化管理平台

为多科室 × 多平台的客服 / 销售对话场景提供：

- **提示词管理**：三维（科室 / 平台 / 场景）+ 变量引擎 + 版本回滚 + 热更新
- **知识库管理**：六类知识标签（答疑 / 问诊 / 套联 / 流程 / 默认认知 / 额外） + 机器人ID标记 + TF-IDF / 语义检索
- **流程树管理**：上传业务流程图（PNG / JPG / PDF），由多模态大模型解析为**纯自然语言描述**
- **LLM 多版本配置**：可在系统中维护多个 OpenAI 兼容 API（base_url / api_key / model），一键切换激活
- **Agent 服务**：独立 8901 端口，提供通用对话接口与流程树解析 UI，与主服务共用同一 SQLite
- **Python 客户端 SDK**：本地缓存 + 自动热更新，零依赖

---

## 1. 项目结构

```
prompt_manager/
├── backend/                     # 主服务（默认 8900）
│   ├── main.py                  # FastAPI：提示词 / 知识库 / 流程树 / LLM 配置 全部 REST + WebSocket
│   ├── database.py              # SQLite CRUD、内存缓存、变量解析引擎、LLM 多版本管理
│   ├── models.py                # Pydantic 请求/响应模型
│   ├── prompt_manager.db        # SQLite 数据库（自动建表迁移）
│   ├── flow_data/               # 流程树原始文件 + LLM API 调用日志
│   ├── requirements.txt
│   └── start.sh
├── agent/                       # Agent 服务（默认 8901）
│   ├── main.py                  # FastAPI：通用对话 + 流程树管理 + 文件直链 + 图片直接解析
│   ├── llm_client.py            # 调主服务取激活 LLM 配置；OpenAI 兼容 chat / chat_with_image
│   ├── flow_parser_service.py   # 统一的流程树解析（主服务亦通过 sys.path 复用此模块）
│   ├── requirements.txt
│   └── start.sh
├── frontend/
│   └── index.html               # 主管理界面（Vue 3 单文件）
├── agent_frontend/              # Agent 前端（独立 SPA）
│   ├── index.html
│   ├── app.js
│   └── style.css
├── client_sdk/
│   ├── __init__.py
│   └── prompt_client.py         # PromptClient：提示词 + 知识库 客户端
├── knowledge_retriever.py       # KnowledgeRetriever：TF-IDF / 语义检索
├── pyproject.toml               # SDK 打包（prompt-manager-client）
└── start.sh                     # 一键启动 主服务 + Agent
```

---

## 2. 各文件的职责与价值

### 2.1 后端 `backend/`

| 文件 | 作用 | 关键点 |
|------|------|--------|
| `database.py` | 全部 SQLite 读写 + 内存缓存 + 变量解析 | 七张表：`prompts`、`prompt_versions`、`knowledge_bases`、`flow_trees`、`flow_records`、`settings`、`llm_versions`；启动时自动 `ALTER TABLE` 迁移；进程内 `_version_cache` 加速热读 |
| `models.py` | Pydantic 模型 | 统一约束 API 输入输出 |
| `main.py` | FastAPI 路由 + WebSocket | 启动时调 `init_db()` + `_init_sample_data()`；流程树上传/重新解析走 `run_in_executor` 后台执行；通过 `sys.path.insert(_AGENT_DIR)` 复用 agent 的 `flow_parser_service` |
| `start.sh` | 单独启动主服务 | `python3 main.py` |

### 2.2 Agent 服务 `agent/`

| 文件 | 作用 | 关键点 |
|------|------|--------|
| `llm_client.py` | OpenAI 兼容客户端 | 启动时 `GET /api/settings/llm/raw` 拉取激活配置；支持 `chat / chat_with_image / chat_with_images`；3 次重试；日志写到 `backend/flow_data/api_logs/llm_api_*.jsonl` |
| `flow_parser_service.py` | **唯一**的流程树解析实现 | OCR（dialogue-flow-parser skill，可缺失自动跳过）+ LLM 多模态；强制输出**自然语言**（无 Markdown / JSON / 列表）；PDF 用 PyMuPDF 优先，pdf2image 兜底；返回前自动清洗格式符号 |
| `main.py` | Agent FastAPI 应用 | 与主服务**共享同一 SQLite**（`PROMPT_DB_PATH=../backend/prompt_manager.db`）；提供 `/api/chat`、`/api/parse_image`、跨库搜索 `/api/flow_records/search`、文件直链 `/api/files/{flow_id}/{name}` |

### 2.3 前端

- **`frontend/index.html`**：单 HTML（Vue 3 CDN），通过模式按钮切换：**提示词管理 / 知识库管理 / 流程树管理**。右上角"齿轮"打开 LLM 多版本管理弹窗；"切换到 Agent" 跳转 8901。
- **`agent_frontend/`**：左侧"流程树图库"（缩略图卡片，可按科室 / 平台 / 关键词跨库搜索），右侧两个 tab：
  - **流程树解析**：图片预览、自然语言描述查看/编辑、重新解析、删除
  - **LLM 对话**：直接调 `/api/chat` 与已配置的大模型对话

### 2.4 客户端 SDK `client_sdk/prompt_client.py`

提示词 + 知识库一站式客户端，所有读取均走本地缓存（线程安全）：

- 提示词：`get / get_content / get_resolved / get_version / get_all_names`
- 知识库：`get_knowledge / get_knowledge_detail / get_knowledge_text / get_all_knowledge / refresh_knowledge`（均支持 `knowledge_type` 和 `bot_id` 筛选）
- 同步与热更新：`preload / start_auto_update / start_ws_update / stop / on_update`

### 2.5 知识库检索 `knowledge_retriever.py`

`KnowledgeRetriever` 提供从对话历史 → 相关知识条目的检索：

- `preload / retrieve / retrieve_as_text / get_available_keys`
- 默认 TF-IDF（无依赖，中文按 unigram + bigram + trigram 切分 + 余弦相似度）
- 可选语义检索：`use_semantic=True`（需 `sentence-transformers + numpy`）

---

## 3. 数据库表结构

| 表 | 关键字段 | 说明 |
|----|----------|------|
| `prompts` | `name UNIQUE`, `department / platform / scene`, `content`, `variables`, `variable_bindings`, `version`, `is_active` | 当前激活提示词 |
| `prompt_versions` | `prompt_id, version, content, change_log` | 全量版本历史 |
| `knowledge_bases` | `(department, platform) UNIQUE`, `content` | `content` 是 JSON 数组：`[{text, type, bot_id}, ...]` |
| `flow_trees` | `(department, platform) UNIQUE`, `description` | 流程树库（科室+平台分组） |
| `flow_records` | `flow_id`, `file_name / file_type / file_path`, `description`, `structure`, `status`, `error` | 一次上传 = 一条记录；`description` 为纯自然语言 |
| `settings` | `key, value` | 旧版 LLM 配置兼容存储位置 |
| `llm_versions` | `name, base_url, api_key, model_name, is_active` | LLM 多版本，激活后自动写入 `settings` |

启动 `init_db()` 时会自动幂等建表，并对旧 `prompts` 缺字段执行 `ALTER TABLE` 迁移、对老的纯字符串知识库内容迁移为 `{text, type, bot_id}` 对象数组（默认 `bot_id` 为 `9378`）。


---

## 4. API 总览

> 主服务前缀 `http://localhost:8900`，Agent 前缀 `http://localhost:8901`。

### 4.1 提示词（主服务）

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/prompts` | 创建 |
| GET | `/api/prompts` | 列表（`department / platform / scene / keyword`，分页） |
| GET | `/api/prompts/{id}` | 详情 |
| PUT | `/api/prompts/{id}` | 更新（内容变更自动版本+1） |
| DELETE | `/api/prompts/{id}` | 软删除 |
| GET | `/api/prompts/{id}/versions` | 版本历史 |
| POST | `/api/prompts/{id}/rollback` | 回滚到指定版本 |
| DELETE | `/api/prompts/{id}/versions/{vid}` | 删除某条历史版本（不允许删当前版本） |
| GET | `/api/v1/fetch?department&platform&scene&current_version` | 三维查询（命中缓存） |
| GET | `/api/v1/fetch/{name}?current_version` | 按名称查询 |
| POST | `/api/v1/resolve` | **变量解析**：返回填充好的提示词 |
| POST | `/api/v1/batch_fetch` | 批量按名称获取 |
| GET | `/api/v1/sync` | 全量同步 |
| GET | `/api/stats` / `/api/debug/cache` / `/api/debug/db` / POST `/api/debug/reload_cache` | 调试 |

### 4.2 知识库（主服务）

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/knowledge` | 创建（`(department, platform)` 唯一） |
| GET | `/api/knowledge` | 列表（`department / platform / keyword`） |
| GET / PUT / DELETE | `/api/knowledge/{id}` | 详情 / 更新 `content` / 删除 |
| GET | `/api/meta/kb_types` | 获取知识标签枚举 |
| GET | `/api/meta/bot_ids` | 获取机器人ID枚举 |

### 4.3 流程树（主服务 + Agent 两端均提供）

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/flow_trees` | 创建流程树库（科室+平台 唯一） |
| GET | `/api/flow_trees` | 列表 |
| GET / PUT / DELETE | `/api/flow_trees/{flow_id}` | 详情 / 改描述 / 删除（级联删记录） |
| GET | `/api/flow_trees/{flow_id}/records` | 库下所有解析记录 |
| POST | `/api/flow_trees/{flow_id}/records/upload` | 上传图片/PDF + 可选自动解析（异步） |
| GET / PUT / DELETE | `/api/flow_records/{record_id}` | 单条记录 |
| POST | `/api/flow_records/{record_id}/reparse` | 重新解析（异步） |
| GET | `/api/flow_records/search`（仅 Agent） | **跨库**搜索：`department/platform/keyword`，返回带 `file_url` |
| GET | `/api/files/{flow_id}/{file_name}`（仅 Agent） | 直链访问上传文件 |
| POST | `/api/parse_image`（仅 Agent） | 上传图片直接解析（不入库） |

### 4.4 LLM 配置（主服务）

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/settings/llm` | 当前激活配置（api_key 已掩码） |
| GET | `/api/settings/llm/raw` | 原始配置（供 Agent 内部调用） |
| PUT | `/api/settings/llm` | 兼容旧接口直接保存 |
| GET / POST / PUT / DELETE | `/api/settings/llm/versions[/{id}]` | 多版本 CRUD（`****` 的 api_key 不会被覆盖） |
| POST | `/api/settings/llm/versions/{id}/activate` | 激活（同步写入 `settings`） |

### 4.5 Agent 通用

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/llm/status` | 检查激活配置是否完整 |
| POST | `/api/llm/refresh` | 清空配置缓存重新拉取 |
| POST | `/api/llm/test` | 一句话探活 |
| POST | `/api/chat` | 通用对话（OpenAI 兼容） |
| GET | `/api/meta/departments` / `/api/meta/platforms` | 元数据 |

### 4.6 WebSocket

`ws://localhost:8900/ws/updates` — 提示词 创建 / 更新 / 删除 / 回滚 事件实时广播。


---

## 5. 提示词请求方式

### 5.1 通过 SDK（推荐）

```python
from prompt_client import PromptClient

client = PromptClient(base_url="http://localhost:8900")
client.preload()                       # 预加载提示词 + 全部知识库到本地缓存
client.start_auto_update(interval=30)  # 30s 轮询热更新

# 拿原文
content = client.get_content("hair_xhs_system")

# 拿"已解析变量"的提示词（最常用）
prompt = client.get_resolved(
    name="hair_xhs_system",
    robot_id="9125",      # {公司} -> 雍禾/碧莲盛/唐森
    current_round=3,      # {轮次} -> 第3轮，{轮次k} -> 3
    action_desc="\n回复意图：问诊、套联",
    knowledge_desc="米诺地尔是常用外用药……",
    warmup_desc="",
    connect_desc="留下联系方式可以安排专业医生……",
)
```

### 5.2 直接 HTTP

```bash
# 按名称取
curl http://localhost:8900/api/v1/fetch/hair_xhs_system

# 三维取
curl "http://localhost:8900/api/v1/fetch?department=hair&platform=xhs&scene=system_prompt"

# 解析变量
curl -X POST http://localhost:8900/api/v1/resolve \
  -H "Content-Type: application/json" \
  -d '{"name":"hair_xhs_system","robot_id":"9125","current_round":3,"action_desc":"\n回复意图：问诊"}'
```

### 5.3 内置变量

| 占位符 | 来源 | 示例 |
|--------|------|------|
| `{公司}` | `robot_id` 映射（`ROBOT_COMPANY_MAP`） | 雍禾 / 碧莲盛 / 唐森 |
| `{域中文}` / `{域英文}` | `department` | 植发科 / hair |
| `{时间}` | 服务器当前时间 | 2026年6月14日 |
| `{轮次}` / `{轮次k}` | `current_round` | 第3轮 / 3 |
| `{动作描述}` / `{知识描述}` / `{暖场描述}` / `{套联描述}` | API 入参对应字段 | — |

### 5.4 自定义变量映射 `variable_bindings`

`variable_bindings` 优先级最高，可把外部传入的字段值替换到任意自定义标记上：

```json
{ "knowledge_desc": "{知识占位符}", "warmup_desc": "{暖场占位符}" }
```


---

## 6. 知识库请求方式

### 6.1 通过 SDK（PromptClient）

```python
# 取整个知识库的文本列表（默认全部类型）
items = client.get_knowledge(department="hair", platform="xhs")

# 按知识标签过滤
qa = client.get_knowledge(department="hair", platform="xhs", knowledge_type="答疑")

# 按机器人ID过滤
kb_9378 = client.get_knowledge(department="hair", platform="xhs", bot_id="9378")

# 同时按知识标签和机器人ID过滤
qa_9378 = client.get_knowledge(department="hair", platform="xhs", knowledge_type="答疑", bot_id="9378")

# 取详情列表（含 type 和 bot_id）
details = client.get_knowledge_detail(department="hair", platform="xhs")
# -> [{"text": "...", "type": "答疑", "bot_id": "9378"}, ...]

# 拼接成单段文本，便于直接插入 prompt
text = client.get_knowledge_text(
    department="hair", platform="xhs",
    knowledge_type="问诊", bot_id="9378", separator="\n"
)

# 一次拿全部
all_kb = client.get_all_knowledge()                   # {"hair/xhs": [...], ...}
all_qa = client.get_all_knowledge(knowledge_type="答疑")
all_9378 = client.get_all_knowledge(bot_id="9378")
```

### 6.2 通过检索器（KnowledgeRetriever）

```python
from knowledge_retriever import KnowledgeRetriever

retriever = KnowledgeRetriever(base_url="http://localhost:8900")
retriever.preload(department="hair", platform="xhs")

history = [
    {"role": "user", "content": "最近掉头发很严重怎么办"},
    {"role": "assistant", "content": "请问您掉发持续多长时间了？"},
]

# 关键词检索（默认）
results = retriever.retrieve(history, "hair", "xhs", top_k=5)

# 按类型筛选
qa_only = retriever.retrieve(history, "hair", "xhs", top_k=5, knowledge_type="答疑")

# 按机器人ID筛选
kb_9378 = retriever.retrieve(history, "hair", "xhs", top_k=5, bot_id="9378")

# 直接拿拼接文本
kb_text = retriever.retrieve_as_text(history, "hair", "xhs", top_k=5, separator="\n")
```

#### 启用语义检索（可选）

```bash
pip install sentence-transformers numpy
```

```python
retriever = KnowledgeRetriever(
    base_url="http://localhost:8900",
    use_semantic=True,
    semantic_model="shibing624/text2vec-base-chinese",
)
```

### 6.3 机器人ID

每条知识记录除了知识类型外，还标记了机器人ID（`bot_id`），用于区分不同机器人使用的知识。前端管理页面左上角提供机器人ID下拉筛选，新建/编辑条目时可选择机器人ID。

默认 `bot_id` 为 `9378`，可选值与 `ROBOT_COMPANY_MAP` 的 key 一致（7422 / 8714 / 8686 / 8542 / 8771 / 9125 / 9378 / 10122 / 10569 / 9352 / 9358 / 9682）。

### 6.4 知识标签

| 标签 | 用途 |
|------|------|
| **答疑** | 解答用户疑问（症状/治疗/效果） |
| **问诊** | 询问用户情况（病史/症状/部位） |
| **套联** | 引导留资（电话/微信） |
| **流程** | 业务流程（就诊/预约） |
| **默认认知** | 通用常识 |
| **额外** | 其他补充 |

### 6.5 知识库内容格式

```json
[
    {"text": "雄激素性脱发表现为头皮渐进性毛发稀疏...", "type": "答疑", "bot_id": "9378"},
    {"text": "请问您脱发持续多长时间了？", "type": "问诊", "bot_id": "9378"},
    {"text": "留下联系方式可以安排专业医生...", "type": "套联", "bot_id": "9378"}
]
```

兼容旧格式（纯字符串数组），加载时自动迁移并标记为「答疑」，`bot_id` 默认为 `9378`。


---

## 7. 流程树描述请求方式

流程树管理的目标是把**业务流程图**（PNG / JPG / PDF 等）转成**纯自然语言描述**，让上游 prompt 可以直接拼接使用。

### 7.1 解析流水线

```
上传文件
   │
   ├──► save_uploaded_file: 落盘到 backend/flow_data/{flow_id}/{ts}_{name}
   │
   └──► parse_file (异步执行)
           │
           ├──► (PDF) pdf_to_images: PyMuPDF / pdf2image 转 200 DPI PNG
           │
           ├──► run_skill_parser: 调 dialogue-flow-parser skill，仅取 OCR 文字
           │
           ├──► parse_image_with_llm: 多模态 LLM (chat_with_image)
           │       system: 强制纯自然语言
           │       user:   "请分析这张流程树图片，用一段自然语言完整描述流程走向。"
           │               + OCR 文字（如有）
           │
           └──► _clean_to_natural: 兜底清洗 Markdown / JSON / 列表 / 编号 / 树形线
```

最终落库 `flow_records.description`（纯自然语言段落）；`structure` 仅保存极简元信息（页数 / 各页状态 / OCR 长度）；`status ∈ {pending, parsing, success, partial, failed, unparsed}`。

> ⚠️ 需要在 LLM 配置里选择**支持视觉的多模态模型**（gpt-4o / qwen-vl / glm-4v / claude-3 / …），否则 `parse_image_with_llm` 会返回 `模型不支持图片输入` 错误。

### 7.2 上传与查询（前端两个入口完全等价，均复用 Agent 的解析实现）

```bash
# ① 上传到指定流程树库（自动解析，异步）
curl -X POST http://localhost:8900/api/flow_trees/1/records/upload \
  -F "file=@flow.png" -F "auto_parse=true"

# ② 拉取记录详情（轮询 status 直到 success / failed）
curl http://localhost:8900/api/flow_records/123

# ③ 重新解析
curl -X POST http://localhost:8900/api/flow_records/123/reparse

# ④ 跨库搜索（Agent 端，附 file_url）
curl "http://localhost:8901/api/flow_records/search?department=hair&platform=xhs&keyword=留资"

# ⑤ 一次性解析图片不入库（Agent 端）
curl -X POST http://localhost:8901/api/parse_image -F "file=@flow.png"
```

### 7.3 把流程描述喂给提示词

```python
client = PromptClient("http://localhost:8900")

# 取业务流程描述（这里以 keyword 拿到唯一记录为例）
import requests
r = requests.get("http://localhost:8901/api/flow_records/search",
                 params={"department": "hair", "platform": "xhs"}).json()
flow_desc = r["items"][0]["description"] if r["items"] else ""

# 解析提示词时把它拼到「动作描述」或自定义变量上
prompt = client.get_resolved(
    name="hair_xhs_system",
    robot_id="9125",
    current_round=3,
    action_desc=f"\n业务流程参考：\n{flow_desc}",
)
```

### 7.4 解析的环境变量

| 变量 | 默认 | 说明 |
|------|------|------|
| `FLOW_DATA_DIR` | `<backend>/flow_data` | 上传文件落盘目录（主服务/Agent 共享） |
| `DIALOGUE_FLOW_PARSER_SKILL` | `~/.codebuddy/skills/dialogue-flow-parser` | OCR skill 根路径，缺失时跳过 OCR |
| `LLM_API_LOG_DIR` | `<flow_data>/api_logs` | LLM API 调用日志目录 |
| `PROMPT_MANAGER_URL` | `http://localhost:8900` | Agent 拉取 LLM 配置的主服务地址 |
| `PROMPT_DB_PATH` | `<backend>/prompt_manager.db` | SQLite 路径，主/Agent 共享同一文件 |


---

## 8. 快速开始

### 8.1 一键启动（主服务 + Agent）

```bash
cd prompt_manager
bash start.sh
# 主服务: http://localhost:8900   API 文档: /docs
# Agent : http://localhost:8901
```

### 8.2 分别启动

```bash
cd backend && pip install -r requirements.txt && python3 main.py   # 8900
cd agent   && pip install -r requirements.txt && python3 main.py   # 8901
```

### 8.3 配置 LLM API（首次必须）

1. 浏览器打开 `http://localhost:8900`
2. 右上角"齿轮"图标 → "新建版本"
3. 填写 base_url（OpenAI 兼容，如 `https://api.openai.com/v1`）、api_key、model_name
4. 点"保存并激活"
5. Agent 端 `http://localhost:8901` 可点击"测试"验证连通

> 流程树解析必须选择**多模态视觉模型**（gpt-4o / qwen-vl-* / glm-4v / claude-3-* 等）。

---

## 9. SDK 安装与发布

```bash
cd client_sdk
pip install -e .          # 本地安装
# 或
cd .. && pip install build && python -m build && pip install dist/*.whl
```

发布到 PyPI：

```bash
pip install twine
twine upload dist/*
```

---

## 10. 元数据枚举

| 科室 | 平台 | 场景 |
|------|------|------|
| `hair`/植发 `dentistry`/口腔 `dermatology`/皮肤 `ophthalmology`/眼科 `pediatrics`/儿科 `beauty`/医美 `general`/通用 | `xhs`/小红书 `bd`/百度 `dy`/抖音 `kuaishou`/快手 `wechat`/微信 `general`/通用 | `system_prompt` `warmup` `knowledge` `action_desc` `general` |

---

## 11. 技术栈

- **后端**：FastAPI + SQLite (WAL) + Pydantic
- **前端**：Vue 3（CDN，零构建）
- **流程树解析**：dialogue-flow-parser skill（OCR）+ OpenAI 兼容多模态 LLM
- **PDF**：PyMuPDF（首选）/ pdf2image（兜底）
- **客户端 SDK**：纯标准库，可选 `websocket-client`、`sentence-transformers`
