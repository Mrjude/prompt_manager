# Prompt Manager · 提示词 / 知识库 / 流程树 一体化管理平台

面向多科室 × 多平台的客服 / 销售对话场景，提供：

- **提示词管理**：科室 × 平台 × 场景三维索引 + 变量引擎 + 版本回滚 + WebSocket 热更新；提示词详情页内嵌"机器人配置看板"，按当前提示词模板显示对应机器人及提示词版本号。
- **知识库管理**：11 类知识标签（含约束 / 违禁词类）+ `bot_id` 机器人维度 + 通用记录合并检索；支持按筛选条件 Excel 导入导出。
- **流程树管理**：上传流程图 / 客服对话截图，视觉能力探测 + OCR 兜底 + LLM 抽象为"一小段自然语言"的核心场景分支逻辑。
- **机器人配置**：将机器人 ID、所属科室 / 平台、公司名（如"雍禾 / 牙博士 / 邦泰"）集中管理，并在 `qwen` 服务热更新到 `ROBOT_DEPT_PLATFORM_MAP` / `ROBOT_COMPANY_MAP`。
- **标签管理**：按 `主题 / 意图 / 动作` 三类组织业务标签。
- **LLM 多版本配置**：维护多个 OpenAI 兼容 API，一键切换激活；流程树解析支持视觉 / 纯文本双模型自动降级。
- **Agent 服务**（`8901`）：独立 LLM 网关 + 流程图谱，提供通用对话、图片直读、跨库搜索、文件直链。
- **Python 客户端 SDK**：本地缓存 + 轮询双通道热更新；公开端点无需鉴权。
- **登录与权限**：内置账号体系，按提示词 / 知识库 / 流程树三大模块细分查看/编辑/删除权限；**普通用户可配置"管理科室列表"**，管理范围之外的内容不可见不可改；admin 不受科室限制。

主服务 `8900`，Agent 服务 `8901`，两者共享同一 SQLite 数据库。

---

## 1. 项目结构

```text
prompt_manager/
├── backend/                       # 主服务（默认 8900）
│   ├── main.py                    # FastAPI：REST + WebSocket + 鉴权中间件 + 公开白名单
│   ├── database.py                # SQLite CRUD、内存缓存、变量解析、用户/会话、LLM/机器人配置
│   ├── models.py                  # Pydantic 模型
│   ├── prompt_manager.db          # SQLite（首次启动自动建表 + 幂等迁移）
│   ├── flow_data/                 # 流程树原始文件 + LLM 调用日志
│   └── start.sh
├── agent/                         # Agent 服务（默认 8901）
│   ├── main.py                    # /api/chat、流程树管理、图片直解析、文件直链
│   ├── llm_client.py              # OpenAI 兼容客户端（chat / chat_with_image(s)）
│   ├── flow_parser_service.py     # 统一流程树解析：视觉能力探测 + OCR 兜底 + 自然语言清洗
│   └── start.sh
├── frontend/
│   ├── index.html                 # 主管理界面（Vue 3，本地 vue.global.prod.js）
│   └── vendor/vue.global.prod.js  # 本地 Vue 运行时（无外网依赖）
├── agent_frontend/                # Agent 前端（index.html + app.js + style.css）
├── client_sdk/
│   ├── prompt_client.py           # PromptClient：提示词 + 知识库 + 流程树 + 机器人配置
│   ├── knowledge_retriever.py     # KnowledgeRetriever：倒排索引 + TF-IDF + 可选语义检索
│   └── __init__.py                # 导出 PromptClient / KnowledgeRetriever
├── knowledge_retriever.py         # 兼容层（re-export client_sdk 实现，旧代码零改动）
├── pyproject.toml                 # SDK 打包（prompt-manager-client）
├── start.sh                       # 一键启动主服务 + Agent
├── AGENT_ARCHITECTURE.md          # Agent 架构设计文档
├── 操作手册.md                     # 页面配置操作手册（面向运营 / 业务方）
└── README.md                      # 本文件
```

---

## 2. 架构与数据流

```text
┌────────────────────────┐         ┌────────────────────────┐
│  主服务 (8900)         │  同库    │  Agent 服务 (8901)     │
│  - 提示词/知识库/流程树 │◀────────▶│  - LLM 对话            │
│  - 用户/权限/登录       │  SQLite  │  - 流程图/对话截图解析 │
│  - LLM 多版本配置       │         │  - 视觉能力探测 + OCR │
│  - 机器人配置管理       │         │  - 跨库搜索/文件直链   │
│  - WebSocket 广播       │         │                        │
└─────────▲──────────────┘         └──────────▲─────────────┘
          │ HTTP / WS                          │ HTTP
   ┌──────┴──────┐                      ┌──────┴──────┐
   │ 主前端 SPA   │                      │ Agent 前端   │
   └──────┬──────┘                      └─────────────┘
          │ SDK（无鉴权，使用 /api/v1/* 公开端点）
          ▼
   ┌─────────────┐         ┌─────────────────┐
   │ PromptClient│         │  qwen 服务（外部）│
   │ + Knowledge │         │  同步机器人配置到 │
   │   Retriever │         │  ROBOT_DEPT_     │
   │             │         │  PLATFORM_MAP    │
   └─────────────┘         └─────────────────┘
```

- 主服务与 Agent 共享同一 SQLite 文件（`PROMPT_DB_PATH`）。
- Agent 通过 `PROMPT_MANAGER_URL` 从主服务读取激活的 LLM 配置（公开 `GET /api/settings/llm/raw`）。
- 主服务通过 `sys.path.insert("../agent")` 直接复用 Agent 的 `flow_parser_service`，避免解析实现分叉。
- LLM 调用日志：`backend/flow_data/api_logs/llm_api_YYYYMMDD.jsonl` + `flow_parser_YYYYMMDD.log`。
- 业务服务（`qwen-proj`）通过 SDK 拉取提示词 / 知识库 / 流程树 / 机器人配置，**全部走 `/api/v1/*` 公开端点，无需 token**。

<!-- ANCHOR:TABLES -->

## 3. 数据库表

| 表                  | 关键字段                                                                                                                      | 说明                                              |
| ------------------- | ----------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------- |
| `prompts`         | `name UNIQUE`, `department/platform/scene`, `content`, `variables`, `variable_bindings`, `version`, `is_active` | 当前激活提示词                                    |
| `prompt_versions` | `prompt_id, version, content, change_log`                                                                                   | 全量版本历史                                      |
| `knowledge_bases` | `(department, platform) UNIQUE`, `content`                                                                                | JSON 数组：`[{text, type, bot_id}, ...]`        |
| `flow_trees`      | `(department, platform) UNIQUE`, `description`                                                                            | 流程树库（按科室+平台分组）                       |
| `flow_records`    | `flow_id`, `file_name`, `file_type`, `file_path`, `description`, `structure`, `status`, `error`, `bot_id`   | 一次上传 = 一条记录；`description` 为纯自然语言 |
| `settings`        | `key, value`                                                                                                                | 旧版 LLM 配置兼容存储                             |
| `llm_versions`    | `name, base_url, api_key, model_name, is_active`                                                                            | LLM 多版本，激活时同步写入`settings`            |
| `users`           | `username UNIQUE, password_hash, role, can_prompt_*/can_knowledge_*/can_flow_*, is_active, **managed_departments**`         | 登录账号 + 页面权限 +**管理科室列表**       |
| `auth_sessions`   | `token, user_id, expires_at`                                                                                                | 登录会话（默认 30 天；服务重启时自动清空）        |
| `bot_ids`         | `bot_id UNIQUE`                                                                                                             | 机器人 ID 白名单（前端下拉候选）                  |
| `robot_configs`   | `bot_id UNIQUE, department, platform, company, enabled, updated_at`                                                         | 机器人配置（`qwen` 服务按此热更新到运行时映射） |
| `tag_records`     | `department, platform, tag_type(主题/意图/动作), name, description, created_at, updated_at`                                 | 标签管理（独立模块）                              |

`flow_records.status ∈ {pending, parsing, success, partial, failed, unparsed}`。

`init_db()` 启动时：

- 幂等建表；对旧 `prompts` 补 `variables`、`variable_bindings` 列；对旧 `users` 补 9 个 `can_*` 权限列。
- 把旧「纯字符串数组」知识库内容迁移为 `{text, type: 答疑, bot_id: 9378}` 对象数组。
- 对旧 `users` 补 `managed_departments` 列（默认 `'[]'`）。
- 若不存在默认管理员，自动创建 `admin / admin123456` 并赋满权限；已存在则强制刷新为 admin 且 9 项权限全开。
- 启动 lifespan 阶段会自动 `clear_auth_sessions()`（参见「安全模型」一节）。

---

## 4. 元数据枚举

| 维度                 | 取值                                                                                                                                                                                                                                             |
| -------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 科室`department`   | `hair` 植发 · `dentistry` 口腔 · `dermatology` 皮肤 · `ophthalmology` 眼科 · `pediatrics` 儿科 · `beauty` 医美 · `thyroid` 甲状腺 · `psychiatry` 精神科 · `andrology` 男科 · `gynaecology` 妇科 · `general` 通用 |
| 平台`platform`     | `xhs` 小红书 · `bd` 百度 · `dy` 抖音 · `kuaishou` 快手 · `wechat` 微信 · `general` 通用                                                                                                                                         |
| 场景`scene`        | `system_prompt` 系统提示词 · `warmup` 暖场语 · `knowledge` 知识模板 · `action_desc` 动作描述 · `score` 评分 · `general` 通用                                                                                                    |
| 知识标签`KB_TYPES` | 答疑 · 问诊 · 套联 · 流程 · 默认认知 · 额外 · 问诊约束 · 答疑约束 · 套联约束 · 核心约束 · 违禁词                                                                                                                                       |
| 标签类型             | `主题` · `意图` · `动作`                                                                                                                                                                                                                 |
| 机器人配置           | 表`robot_configs`：`bot_id`（唯一）/ `department` / `platform` / `company`（如 雍禾、牙博士、邦泰）/ `enabled`                                                                                                                       |
| 内置机器人 ID        | `7422 / 8714 / 8686 / 8542 / 8771 / 9125 / 9378 / 10122 / 10569 / 9352 / 9358 / 9682`                                                                                                                                                          |
| 内置变量             | `{公司} {域中文} {域英文} {时间} {轮次} {轮次k} {套联描述} {动作描述} {知识描述} {暖场描述}`                                                                                                                                                   |

`{公司}` 默认通过 `ROBOT_COMPANY_MAP` 由 `robot_id` 映射为 `雍禾 / 碧莲盛 / 唐森`；当 `robot_configs` 中显式配置了 `company` 时，**该映射被远端配置覆盖**。

## 5. API 概览

> 主服务前缀 `http://localhost:8900`，Agent 前缀 `http://localhost:8901`。字段详情见 `http://localhost:8900/docs`。

### 5.1 公开白名单（无需登录）

中间件 `auth_middleware` 跳过以下前缀：

```python
PUBLIC_API_PREFIXES = (
    "/api/auth/login", "/api/auth/heartbeat", "/api/v1/", "/api/meta/", "/api/settings/",
    "/docs", "/openapi.json", "/redoc", "/favicon.ico"
)
```

### 5.2 登录与权限

| 方法                | 路径                  | 说明                                                                   |
| ------------------- | --------------------- | ---------------------------------------------------------------------- |
| POST                | `/api/auth/login`   | 用户名密码登录，返回`token` + `user`                               |
| GET                 | `/api/auth/me`      | 当前登录用户（Header`Authorization: Bearer` 或 cookie `pm_token`） |
| POST                | `/api/auth/logout`  | 注销 token                                                             |
| GET/POST/PUT/DELETE | `/api/users[/{id}]` | admin：账号 CRUD（含`managed_departments` 字段）                     |

权限中间件白名单之外的其他 `/api/**`，未登录返回 401，不满足对应 `can_*` 位返回 403。普通用户的 `data.department` 不在 `managed_departments` 内时，创建/更新/导入直接返回 403。

### 5.3 提示词（主服务）

| 方法               | 路径                                                        | 说明                                                      |
| ------------------ | ----------------------------------------------------------- | --------------------------------------------------------- |
| POST               | `/api/prompts`                                            | 创建；非 admin 校验`department` 在管理科室内            |
| GET                | `/api/prompts`                                            | 列表（`department / platform / scene / keyword`，分页） |
| GET / PUT / DELETE | `/api/prompts/{id}`                                       | 详情 / 更新（内容变更版本+1） / 软删除                    |
| GET                | `/api/prompts/{id}/versions`                              | 版本历史                                                  |
| POST               | `/api/prompts/{id}/rollback`                              | 回滚到指定版本                                            |
| DELETE             | `/api/prompts/{id}/versions/{vid}`                        | 删除某条历史版本（禁止删当前版本）                        |
| GET                | `/api/v1/fetch?department&platform&scene&current_version` | 三维查询（命中内存缓存；**无需 token**）            |
| GET                | `/api/v1/fetch/{name}?current_version`                    | 按名称查询（无需 token）                                  |
| POST               | `/api/v1/resolve`                                         | 变量解析：返回填充好的提示词（无需 token）                |
| POST               | `/api/v1/batch_fetch`                                     | 批量按名称获取（无需 token）                              |
| GET                | `/api/v1/sync`                                            | 全量同步（供 SDK 冷启动；无需 token）                     |

调试：`/api/stats`、`/api/debug/cache`、`/api/debug/db`、`POST /api/debug/reload_cache`。

### 5.4 知识库（主服务）

| 方法               | 路径                       | 说明                                                                                                |
| ------------------ | -------------------------- | --------------------------------------------------------------------------------------------------- |
| POST               | `/api/knowledge`         | 创建（`(department, platform)` 唯一）；非 admin 校验科室                                          |
| GET                | `/api/knowledge`         | 列表（`department / platform / keyword`）；**非 admin 自动加 `managed_departments` 过滤** |
| GET / PUT / DELETE | `/api/knowledge/{kb_id}` | 详情 / 更新`content` / 删除                                                                       |
| GET                | `/api/knowledge/export`  | 按当前筛选导出为 Excel（`xlsx`）；表头 `科室, 平台, 类型, 机器人ID, 知识内容`                   |
| POST               | `/api/knowledge/import`  | 上传 Excel 导入（按`(dept, plat)` 合并到现有内容；非 admin 跳过越权科室行）                       |
| GET                | `/api/v1/knowledge`      | 供 SDK 拉取（公开只读，无需 token）                                                                 |
| GET                | `/api/meta/kb_types`     | 知识标签枚举（含约束/违禁词类）                                                                     |
| GET / POST         | `/api/meta/bot_ids`      | 机器人 ID 枚举（GET 查询、POST 追加，POST 需知识库编辑权限）                                        |

### 5.5 流程树（主服务 + Agent 双端提供）

| 方法               | 路径                                          | 说明                                                                                                         |
| ------------------ | --------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| POST               | `/api/flow_trees`                           | 创建流程树库（`科室+平台` 唯一）；非 admin 校验科室                                                        |
| GET                | `/api/flow_trees`                           | 列表（`department / platform / keyword / bot_id`），**非 admin 自动加 `managed_departments` 过滤** |
| GET / PUT / DELETE | `/api/flow_trees/{flow_id}`                 | 详情 / 改描述 / 删除（级联删记录）                                                                           |
| GET                | `/api/flow_trees/{flow_id}/records`         | 库下所有解析记录                                                                                             |
| POST               | `/api/flow_trees/{flow_id}/records/upload`  | 上传图片/PDF + 可选自动解析（主服务异步、Agent 同步）                                                        |
| GET / PUT / DELETE | `/api/flow_records/{record_id}`             | 单条记录                                                                                                     |
| POST               | `/api/flow_records/{record_id}/reparse`     | 重新解析                                                                                                     |
| GET                | `/api/flow_records/search`（Agent）         | 跨库搜索：`department / platform / keyword`，附 `file_url`                                               |
| GET                | `/api/files/{flow_id}/{file_name}`（Agent） | 直链访问上传文件                                                                                             |
| POST               | `/api/parse_image`（Agent）                 | 上传图片直接解析（不入库）                                                                                   |
| GET                | `/api/v1/flow_records/search`（主服务）     | 供 SDK 拉取流程树描述（公开只读）                                                                            |

### 5.6 机器人配置（主服务）

| 方法   | 路径                                                                    | 说明                                                          |
| ------ | ----------------------------------------------------------------------- | ------------------------------------------------------------- |
| GET    | `/api/robot_configs`                                                  | 列表（需`require_knowledge_view`）                          |
| POST   | `/api/robot_configs`                                                  | 写入或更新（需`require_knowledge_edit`）                    |
| GET    | `/api/robot_configs/{bot_id}`                                         | 详情                                                          |
| PUT    | `/api/robot_configs/{bot_id}`                                         | 局部更新（需`require_knowledge_edit`）                      |
| DELETE | `/api/robot_configs/{bot_id}`                                         | 删除（需`require_knowledge_edit`）                          |
| GET    | `/api/v1/robot_configs`                                               | 公开只读，供 SDK 拉取（**无需 token**）                 |
| GET    | `/api/v1/robot_configs/{bot_id}/prompt_version?department=&platform=` | 公开只读，返回该机器人在指定科室+平台下命中的提示词最新版本号 |

> `qwen` 服务通过 `GET /api/v1/robot_configs`（公开）定期拉取并热更新 `ROBOT_DEPT_PLATFORM_MAP` / `ROBOT_COMPANY_MAP`；用户在前端修改/启用/停用会通过 30s 轮询回调自动同步，无需重启业务服务。

### 5.7 LLM 配置（主服务）

| 方法                      | 路径                                         | 说明                                                       |
| ------------------------- | -------------------------------------------- | ---------------------------------------------------------- |
| GET                       | `/api/settings/llm`                        | 当前激活配置（api_key 掩码）                               |
| GET                       | `/api/settings/llm/raw`                    | 原始配置（Agent 内部调用，无需 token）                     |
| PUT                       | `/api/settings/llm`                        | 兼容旧接口直接保存                                         |
| GET / POST / PUT / DELETE | `/api/settings/llm/versions[/{id}]`        | 多版本 CRUD（`****` 的 `api_key` 保持不变）            |
| POST                      | `/api/settings/llm/versions/{id}/activate` | 激活（同步写入`settings` 与 `llm_versions.is_active`） |

### 5.8 Agent 通用

| 方法 | 路径                                                | 说明                      |
| ---- | --------------------------------------------------- | ------------------------- |
| GET  | `/api/llm/status`                                 | 检查激活配置是否完整      |
| POST | `/api/llm/refresh`                                | 清空 LLM 配置缓存重新拉取 |
| POST | `/api/llm/test`                                   | 一句话探活                |
| POST | `/api/chat`                                       | 通用对话（OpenAI 兼容）   |
| GET  | `/api/meta/departments` / `/api/meta/platforms` | 元数据                    |

### 5.9 WebSocket

- `ws://localhost:8900/ws/updates`
- 提示词 创建 / 更新 / 删除 / 回滚 事件实时广播；SDK 需安装 `websocket-client` 即可订阅。

<!-- ANCHOR:PROMPTSDK -->

## 6. 提示词使用指南

### 6.1 通过 SDK（推荐）

```python
from client_sdk import PromptClient   # or: from prompt_client import PromptClient

client = PromptClient(base_url="http://localhost:8900")
client.preload()                       # 预加载提示词 + 知识库 + 流程树 + 机器人配置
client.start_auto_update(interval=30)  # 30s 轮询热更新
# client.start_ws_update()             # 或走 WebSocket，需 pip install websocket-client

# 拿原文
content = client.get_content("hair_xhs_system")

# 拿"已解析变量"的提示词（最常用）
prompt = client.get_resolved(
    name="hair_xhs_system",
    robot_id="9125",       # {公司} → 雍禾/碧莲盛/唐森（由 ROBOT_COMPANY_MAP 解析）
    department="hair",
    current_round=3,       # {轮次} → 第3轮，{轮次k} → 3
    action_desc="\n回复意图：问诊、套联",
    knowledge_desc="米诺地尔是常用外用药……",
    warmup_desc="",
    connect_desc="留下联系方式可以安排专业医生……",
    extra_variables={"custom_marker": "客服话术片段"},  # 结合 variable_bindings 使用
)
```

> 缓存注意：`get_resolved` 的缓存 key 包含 `extra_variables`，避免外部变量（知识库 / 流程树 / extra_variables）更新后仍命中旧结果。

### 6.2 直接 HTTP

```bash
# 按名称取
curl http://localhost:8900/api/v1/fetch/hair_xhs_system

# 三维取
curl "http://localhost:8900/api/v1/fetch?department=hair&platform=xhs&scene=system_prompt"

# 变量解析
curl -X POST http://localhost:8900/api/v1/resolve \
  -H "Content-Type: application/json" \
  -d '{"name":"hair_xhs_system","robot_id":"9125","current_round":3,"action_desc":"\n回复意图：问诊"}'
```

### 6.3 变量解析规则

优先级：`variable_bindings 映射 > 内置变量 > variables 自定义变量 > extra_variables 直接替换`。

- **内置变量**：由 `resolve_prompt_variables` 自动填充，见「元数据枚举」。
- **`variable_bindings`**：管理页面在"变量映射"里维护，格式 `{"变量名": "占位符标记"}`，可把外部字段绑定到任意自定义标记：

```json
{
  "warmup_desc": "{暖场占位符}",
  "knowledge_desc": "{知识占位符}"
}
```

- **`extra_variables`**：在 `resolve` 调用里传入，键名与 `variable_bindings` 对应，可动态注入。

---

## 7. 知识库使用指南

### 7.1 内容格式

```json
[
  {"text": "雄激素性脱发表现为头皮渐进性毛发稀疏……", "type": "答疑", "bot_id": "9378"},
  {"text": "请问您脱发持续多长时间了？",              "type": "问诊", "bot_id": "9378"},
  {"text": "留下联系方式可以安排专业医生……",       "type": "套联", "bot_id": "9378"},
  {"text": "禁止提及具体药品名和价格……",            "type": "违禁词", "bot_id": ""}
]
```

- `type ∈ KB_TYPES`。
- `bot_id` 为空字符串表示「通用记录」：SDK 在按 `bot_id` 过滤时，会**同时命中该 bot_id 的记录和 `bot_id == ""` 的通用记录**。
- 旧「纯字符串数组」格式启动时自动迁移。

### 7.2 导入导出

- 导出：`GET /api/knowledge/export?department=&platform=&keyword=&bot_id=` 返回 `xlsx`，表头 `科室, 平台, 类型, 机器人ID, 知识内容`。
- 导入：`POST /api/knowledge/import`（multipart `file` + `upsert`）按 `(科室, 平台)` 合并到现有内容。普通用户仅能导入到自己管理科室内。
- UI：知识库管理页右上角"导出 / 导入"按钮，无需任何额外权限。

### 7.3 通过 SDK 使用

```python
# 全部条目文本
items = client.get_knowledge(department="hair", platform="xhs")

# 按知识标签过滤
qa = client.get_knowledge(department="hair", platform="xhs", knowledge_type="答疑")

# 按机器人 ID 过滤（会同时命中 bot_id="" 的通用记录）
kb_9378 = client.get_knowledge(department="hair", platform="xhs", bot_id="9378")

# 详情列表（含 type / bot_id）
details = client.get_knowledge_detail(department="hair", platform="xhs")

# 拼接为单段文本，便于直接插入 prompt
text = client.get_knowledge_text(
    department="hair", platform="xhs",
    knowledge_type="问诊", bot_id="9378", separator="\n"
)
```

### 7.4 通过检索器（KnowledgeRetriever）

> 自 SDK `0.3.0` 起，检索器已整合进 `client_sdk`，并做了 9 项性能优化。
> 旧路径 `from knowledge_retriever import KnowledgeRetriever` 仍可用（兼容层 re-export）。

#### 7.4.1 基础用法

```python
from client_sdk import KnowledgeRetriever

retriever = KnowledgeRetriever(base_url="http://localhost:8900")
retriever.preload(department="hair", platform="xhs")

history = [
    {"role": "user", "content": "最近掉头发很严重怎么办"},
    {"role": "assistant", "content": "请问您掉发持续多长时间了？"},
]

# 关键词检索（倒排索引 + TF-IDF 加权余弦）
results = retriever.retrieve(history, "hair", "xhs", top_k=5)

# 按类型 / 机器人过滤（bot_id 传具体值时同时命中 bot_id="" 的通用记录）
kb = retriever.retrieve(history, "hair", "xhs", top_k=5, knowledge_type="答疑", bot_id="9378")

# 直接拿拼接文本插入 prompt
kb_text = retriever.retrieve_as_text(history, "hair", "xhs", top_k=5, separator="\n")

# 带分数返回，便于调试与二次排序
scored = retriever.retrieve_with_scores(history, "hair", "xhs", top_k=5)
# -> [("脱发主要分为雄激素性脱发和斑秃两大类", 0.4821), ...]

# 索引统计（排查检索效果与内存占用）
print(retriever.stats())
# -> {'kb_count': 1, 'total_items': 168, 'indexed_keys': ['hair/xhs'],
#     'vocab_sizes': {'hair/xhs': 3241}, 'semantic': False}
```

#### 7.4.2 复用 PromptClient 缓存（推荐，零网络请求）

```python
from client_sdk import PromptClient, KnowledgeRetriever

client = PromptClient(base_url="http://localhost:8900")
client.preload()                      # 已经拉过一次知识库

retriever = KnowledgeRetriever(prompt_client=client)   # 直接读 client._kb_cache
retriever.preload(department="hair", platform="xhs")   # 不再发 HTTP 请求
```

业务服务（如 `qwen-proj`）里若已经有 `PromptClient` 实例，务必用这种方式，避免重复拉取与重复解析。

#### 7.4.3 语义检索（可选）

```bash
pip install "prompt-manager-client[semantic]"
# 等价于 pip install sentence-transformers numpy
```

```python
retriever = KnowledgeRetriever(
    base_url="http://localhost:8900",
    use_semantic=True,
    semantic_model="shibing624/text2vec-base-chinese",
)
retriever.preload(department="hair", platform="xhs")

# method="auto"：装了语义模型走语义，否则自动回退关键词
results = retriever.retrieve(history, "hair", "xhs", top_k=5, method="auto")
# 强制指定
results = retriever.retrieve(history, "hair", "xhs", top_k=5, method="keyword")
results = retriever.retrieve(history, "hair", "xhs", top_k=5, method="semantic")
```

#### 7.4.4 构造参数

| 参数                | 默认值                                  | 说明                                                                 |
| ------------------- | --------------------------------------- | -------------------------------------------------------------------- |
| `base_url`        | `http://localhost:8900`               | 主服务地址；使用公开端点 `/api/v1/knowledge`，**无需鉴权**       |
| `use_semantic`    | `False`                               | 是否启用语义检索（需 `sentence-transformers`）                     |
| `semantic_model`  | `shibing624/text2vec-base-chinese`    | 语义编码模型                                                         |
| `prompt_client`   | `None`                                | 传入 `PromptClient` 实例可复用其知识库缓存，零网络请求             |
| `enable_stopwords`| `True`                                | 停用词过滤；关闭后回到旧版分词行为                                   |

#### 7.4.5 检索方法一览

| 方法                                   | 返回                          | 说明                                             |
| -------------------------------------- | ----------------------------- | ------------------------------------------------ |
| `preload(department, platform)`       | `None`                      | 拉取数据 + 构建倒排索引 / 分组索引 / 向量索引    |
| `retrieve(...)`                       | `List[str]`                 | 文本列表，按相关度降序                           |
| `retrieve_with_scores(...)`           | `List[Tuple[str, float]]`   | 带相关度分数                                     |
| `retrieve_as_text(...)`               | `str`                       | 用 `separator` 拼接为单段文本                  |
| `get_available_keys()`                | `List[str]`                 | 已缓存的 `"dept/plat"` 列表                    |
| `stats()`                             | `dict`                      | 索引统计：条目数 / 词表大小 / 是否启用语义        |

#### 7.4.6 性能优化说明（v0.3.0）

`preload()` 时一次性构建三套索引，之后每次 `retrieve()` **零网络延迟、零重复计算**：

| 索引               | 结构                                          | 作用                                            |
| ------------------ | --------------------------------------------- | ----------------------------------------------- |
| **倒排索引**   | `{term: {doc_idx: tfidf}}`                  | 只遍历命中查询词的文档，跳过全部无关文档        |
| **文档范数表** | `{doc_idx: L2_norm}`                        | 预计算，检索时直接查表算余弦                    |
| **分组索引**   | `{(type, bot_id): frozenset(doc_idx)}`      | `knowledge_type` / `bot_id` 筛选 O(1) 命中  |
| **向量索引**   | 预 L2 归一化的 `np.ndarray`                 | 点积即余弦相似度，省掉每次 norm                 |

相比旧实现的 9 项改进：

| #  | 优化点                       | 优化前                                        | 优化后                                | 复杂度改善                  |
| -- | ---------------------------- | --------------------------------------------- | ------------------------------------- | --------------------------- |
| 1  | 倒排索引                     | 遍历全部文档算相似度                          | 只累加命中查询词的文档                | O(n) → **O(\|q\|·df)**  |
| 2  | 预计算文档范数               | 每次检索重算每个文档 L2 norm                  | 建索引时算一次                        | 省掉重复 O(n·\|V\|)         |
| 3  | `heapq.nlargest` 取 TopK   | `sorted()` 全排序                           | 堆选 TopK                             | O(n log n) → **O(n log k)** |
| 4  | 位置索引替代对象比较         | `item not in search_items`（dict 深度比较） | `frozenset` 位置集合                | **O(n×m) → O(1)**       |
| 5  | 分组预筛索引                 | 每次 `for item in items` 逐项过滤           | 建索引时预建 `(type, bot_id)` 集合  | O(n) → **O(1) 命中**    |
| 6  | 语义向量预归一化             | 每次 `np.linalg.norm` 逐条算                | 建索引时统一归一化                    | 省掉每次 norm               |
| 7  | `np.argpartition` 选 TopK  | `np.argsort` 全排序                         | 分区选 TopK 再排序 K 个               | O(n log n) → **O(n)**   |
| 8  | 停用词 + 分词降噪            | 全部单字 / bigram / trigram 入表              | 过滤 130+ 停用词与低区分度单字        | token 减约 **30%**      |
| 9  | **修复鉴权 Bug**         | 用 `/api/knowledge`（需登录）→ 必然 401    | 改用 `/api/v1/knowledge` 公开端点   | 从"不可用"到可用           |

**分词策略**：中文按「高区分度单字 + bigram + trigram」切分，英文取 ≥2 字母单词，数字单独成 token；`_STOPWORDS`（130+ 词）与 `_SINGLE_CHAR_KEEP`（症状类单字白名单）共同控制噪声。

**查询构造**：取最近 6 轮对话，**用户消息优先**；最后 2 条用户消息重复计入，提升近期意图权重。


---

## 8. 流程树使用指南

流程树把「业务流程图」或「客服对话截图」抽象为**纯自然语言**的核心场景分支逻辑，用于直接拼进 prompt。

### 8.1 解析流水线

```text
上传文件 (image / pdf)
   │
   ├── save_uploaded_file: 落盘到 backend/flow_data/{flow_id}/{ts}_{name}
   │
   └── parse_file  (可异步执行)
         │
         ├── (PDF)  pdf_to_images: PyMuPDF 优先，pdf2image 兜底，200 DPI
         │
         ├── run_skill_parser: 调 dialogue-flow-parser skill 只取 OCR 文本
         │        └─ 缺依赖时自动 fallback 到内置 rapidocr（进程内 或 跨解释器）
         │
         ├── _probe_vision_capability: 探测当前激活 LLM 是否真的能读图
         │        (发一张 1×1 探测图 + 单字问答；结果按 base_url+model 缓存)
         │
         ├── 若支持视觉  → llm.chat_with_image(SYSTEM_PROMPT + OCR 锚点)
         │   若不支持    → llm.chat(SYSTEM_PROMPT + OCR 文本)
         │
         └── _clean_to_natural: 剥离 Markdown / JSON / 列表 / 编号 / 树形线
```

- `flow_records.description` 存**纯自然语言段落**（60~180 字，最多 250 字）；`structure` 只保存最小页面元信息（页数 / 每页状态 / OCR 长度）。
- `status ∈ {pending, parsing, success, partial, failed, unparsed}`。
- 系统提示词能同时识别 A) 流程图 和 B) 客服对话截图，并把对话抽象为「如果访客… 则客服… 否则…」的循环流程逻辑，敏感信息（城市名/门店名/时间戳/姓名/手机号）自动脱敏。

### 8.2 视觉 / OCR 兼容矩阵

| LLM 是否支持图片输入                              | 处理路径                      | 依赖                                             |
| ------------------------------------------------- | ----------------------------- | ------------------------------------------------ |
| 支持（如`qwen-vl-max`、`gpt-4o`、`glm-4v`） | 多模态直读 + OCR 锚点         | LLM 视觉能力                                     |
| 不支持（如`deepseek-v4-flash`）                 | OCR 抽文本 + 纯文本 chat 抽象 | `rapidocr_onnxruntime`（推荐）或 `paddleocr` |

- 视觉能力探测结果按 `(base_url, model)` 缓存，切换 LLM 版本时自动重探。
- OCR Python 解释器探测顺序：`OCR_PYTHON` 环境变量 → `sys.executable` → `/data/miniconda3/bin/python3` → `/usr/bin/python3` → `which python3`。找到装了 `rapidocr_onnxruntime` 的即用。
- 建议给服务运行环境装一次 `pip install rapidocr_onnxruntime`，兜底才最稳。

### 8.3 上传与查询

```bash
# ① 主服务：上传到指定流程树库（自动异步解析）
curl -X POST http://localhost:8900/api/flow_trees/1/records/upload \
     -F "file=@flow.png" -F "auto_parse=true"

# ② 拉取记录详情（轮询 status 直到 success / failed）
curl http://localhost:8900/api/flow_records/123

# ③ 重新解析
curl -X POST http://localhost:8900/api/flow_records/123/reparse

# ④ 跨库搜索（Agent 端，附 file_url）
curl "http://localhost:8901/api/flow_records/search?department=hair&platform=xhs&keyword=留资"

# ⑤ 一次性解析图片不入库（Agent 端）
curl -X POST http://localhost:8901/api/parse_image -F "file=@flow.png"
```

### 8.4 把流程描述拼给提示词

```python
flow_desc = client.get_flow_descriptions(department="hair", platform="xhs")

prompt = client.get_resolved(
    name="hair_xhs_system",
    robot_id="9125",
    current_round=3,
    action_desc=f"\n业务流程参考：\n{flow_desc}",
)
```

---

## 9. 机器人配置与 qwen 服务热更新

### 9.1 后端模型

`robot_configs` 表存储 4 字段：

| 字段           | 含义                                                    |
| -------------- | ------------------------------------------------------- |
| `bot_id`     | 机器人 ID（唯一）                                       |
| `department` | 所属科室（如`hair`）                                  |
| `platform`   | 所属平台（如`xhs`）                                   |
| `company`    | 公司名（雍禾 / 牙博士 / 邦泰 等）                       |
| `enabled`    | 是否启用（`enabled=0` 的不会被 SDK 同步到运行时映射） |

### 9.2 公开端点

`GET /api/v1/robot_configs`（**无需 token**）是 SDK 的统一拉取入口，返回全量启用的机器人配置。`qwen` 服务通过这个公开端点拉取，避免鉴权耦合。

### 9.3 qwen 服务热更新

`qwen-proj/llm_service/service_qwen_controller.py` 内置两个模块级映射：

```python
_DEFAULT_ROBOT_DEPT_PLATFORM_MAP = {
    "7422": ("hair", "xhs", "雍禾"),
    "9378": ("hair", "xhs", "雍禾"),
    # ... 默认值（保留以便远端未配置时回退）
}
ROBOT_DEPT_PLATFORM_MAP: Dict[str, Tuple[str, str, str]] = dict(_DEFAULT_ROBOT_DEPT_PLATFORM_MAP)
ROBOT_COMPANY_MAP: Dict[str, str] = {}
```

`rebuild_robot_maps_from_configs(configs)` 行为：

1. 把远端启用的条目按 `bot_id` 覆盖默认值（合并到 `new_map`）；
2. 默认值中**未在远端显式出现的** bot_id 仍然保留（始终基于 `_DEFAULT_*` 常量，避免被前一次远程结果污染）；
3. `ROBOT_COMPANY_MAP` 只从远端 `company` 非空的条目写入。

热更新链路：

- `qwen` 服务启动 → `prompt_client.preload()` 拉一次远端 → `rebuild_robot_maps_from_configs` 重建运行时映射 → 启动 `start_auto_update(interval=30)` 周期同步。
- 任意一次轮询检测到远端 `robot_configs` 变化 → SDK 通过 `on_update` 回调 `key="robot_configs"` 通知业务侧 → 业务侧再次 `rebuild_robot_maps_from_configs` 并调用 `_load_knowledge_attrs()` 重载各机器人知识库属性。

### 9.4 详情页"机器人配置看板"

提示词详情页（`mode === 'prompt'`，`!editing`）会在"描述"之后、"提示词内容"之前展示机器人配置看板：

- 仅当 `currentPromptDept` + `currentPromptPlat` 下存在机器人配置时才显示（`v-if="robotMatchedList.length"`）。
- 每行展示：机器人 ID / 科室 / 平台 / 公司名 / **提示词版本（`vN` 或 `无`）** / 状态 / 更新时间 / 操作。
- 提示词版本号由后端 `GET /api/v1/robot_configs/{bot_id}/prompt_version?department=&platform=` 返回（无需 token）。
- 进入编辑态（`v-if="editing"`）时，看板**始终显示**（无数据时显示空态行 + 「+ 新增条目」按钮），可即时新增/编辑/删除机器人配置。

---

## 10. LLM 配置与多版本切换

- 在主前端右上角「齿轮」图标进入 LLM 版本管理。
- 支持维护多个 OpenAI 兼容 API 版本（`base_url` / `api_key` / `model_name`），一键激活。
- `api_key` 在 GET `/api/settings/llm` 返回时会掩码，PUT 更新时若包含 `****` 则不覆盖。
- 激活时同步写入 `llm_versions.is_active` 与旧格式 `settings` 表，保证 SDK / Agent 读取一致。
- 变更配置后调用 `POST http://localhost:8901/api/llm/refresh` 或重启 Agent 让缓存生效；切换 LLM 后 SDK 内部 `VisionCapabilityCache` 也会清空，下次调用重新探测视觉能力。

**多模态模型建议**：

- 若解析流程图，优先选支持视觉输入的模型（`qwen-vl-max` / `qwen-vl-plus` / `gpt-4o` / `glm-4v` / `claude-3-5-sonnet`）。
- 若模型不支持图片（如 `deepseek-v4-flash`），系统会自动降级为 OCR + 文本 chat，仍能得到抽象流程描述。

---

## 11. 用户管理与"管理科室"权限

### 11.1 账号模型

- `role`：`admin`（高级权限） 或 `normal`（普通权限）。
- 9 个 `can_*` 权限位：`can_prompt_view / can_prompt_edit / can_prompt_delete`、`can_knowledge_*`、`can_flow_*`。
- `managed_departments`（JSON 数组）：**仅对 `normal` 生效**。admin 创建时该字段写空列表；保存时由前端按用户角色决定是否传。

### 11.2 普通用户可见范围

| 场景         | 行为                                                                              |
| ------------ | --------------------------------------------------------------------------------- |
| 列表查询     | 提示词 / 知识库 / 流程树 列表自动追加`department IN (managed_departments)` 过滤 |
| 创建/更新    | 校验`data.department` 是否在 `managed_departments` 内，否则 `403`           |
| 知识库导入   | 跳过非授权科室的行（`skipped++`），不阻断整体导入                               |
| 顶部科室下拉 | 仅显示`managed_departments` 中的项；admin 才出现"全部科室"                      |

admin 角色完全不受 `managed_departments` 限制，看到全部。

### 11.3 账户权限页面（admin 专用）

- 用户名 / 权限 / 状态 / 管理科室标签 / 创建时间。
- 编辑表单：9 个 `can_*` 勾选 + **管理科室多选**（按住 Ctrl / ⌘ 多选；admin 隐藏该项）。

### 11.4 安全模型

- 登录成功后 `auth_sessions` 写入 `token`，默认 30 天过期。
- **服务启动时 `clear_auth_sessions()` 会清空所有会话**，即"重启 = 强制全部用户重新登录"。这是有意为之，避免长时间无主 token 累积。
- 主前端 `index.html` 由 `Cache-Control: no-store, no-cache, must-revalidate, max-age=0` 头控制，禁止浏览器缓存。

---

## 12. 快速开始

### 12.1 一键启动（主服务 + Agent）

```bash
cd prompt_manager
bash start.sh
# 主服务:  http://localhost:8900   API 文档: /docs
# Agent :  http://localhost:8901
```

### 12.2 分别启动

```bash
# 主服务
cd backend && pip install -r requirements.txt && python3 main.py       # 8900

# Agent 服务
cd agent   && pip install -r requirements.txt && python3 main.py       # 8901
# 建议再装 OCR：pip install rapidocr_onnxruntime
```

### 12.3 首次使用流程

1. 浏览器打开 `http://localhost:8900`。
2. 使用默认账号 `admin / admin123456` 登录。
3. 右上角「齿轮」进入 LLM 配置，新增一个 OpenAI 兼容版本 → 「保存并激活」。
4. 需要解析流程图时，激活支持视觉的模型；否则任意兼容模型均可，Agent 会自动 OCR 兜底。
5. 打开 `http://localhost:8901` 或 `POST /api/llm/test` 验证连通性。
6. 「账户权限」中创建普通用户并指派管理科室（如 `['hair','dentistry']`），该用户登录后只能看到/管理这两个科室下的提示词、知识库、流程树。

---

## 13. Python SDK

包名：`prompt-manager-client`（源码在 `client_sdk/`）。

### 13.1 安装

```bash
# 源码开发安装
cd prompt_manager
pip install -e .

# 或打包安装
pip install build
python -m build
pip install dist/prompt_manager_client-*.whl

# 可选依赖：WebSocket 热更新
pip install "prompt-manager-client[ws]"

# 可选依赖：语义检索（KnowledgeRetriever use_semantic=True）
pip install "prompt-manager-client[semantic]"
```

发布到 PyPI：

```bash
pip install twine
python -m build
twine upload dist/*
```

### 13.2 核心接口

`PromptClient`（详见 `client_sdk/prompt_client.py`）：

- 构造：`PromptClient(base_url="http://localhost:8900")`，**仅使用 `/api/v1/*` 公开端点，无需鉴权**
- 提示词：`get / get_content / get_resolved / get_version / get_all_names`
- 知识库：`get_knowledge / get_knowledge_detail / get_knowledge_text / get_all_knowledge / refresh_knowledge`
- 流程树：`get_flow_records / get_flow_descriptions / refresh_flow_records`
- 机器人配置：`refresh_robot_configs / get_robot_configs(department, platform, enabled_only)`
- 生命周期：`preload / on_update / start_auto_update / start_ws_update / stop`

`on_update` 回调 key：

- `kb:{dept}/{plat}` — 知识库更新
- `robot_configs` — 机器人配置列表变化

`KnowledgeRetriever`（详见 `client_sdk/knowledge_retriever.py`，v0.3.0 起整合进 SDK）：

- 构造：`KnowledgeRetriever(base_url=..., use_semantic=False, prompt_client=None, enable_stopwords=True)`
- 关键词检索：**倒排索引** + TF-IDF 加权余弦（中文高区分度单字 / bigram / trigram + 停用词过滤）
- 可选语义检索：`use_semantic=True`（需 `pip install "prompt-manager-client[semantic]"`）
- 接口：`preload / retrieve / retrieve_with_scores / retrieve_as_text / get_available_keys / stats`
- 复用缓存：传 `prompt_client=<PromptClient 实例>` 可零网络请求初始化
- 兼容层：`from knowledge_retriever import KnowledgeRetriever` 仍可用
- 详细优化说明见「7.4.6 性能优化说明」

---

## 14. 环境变量

| 变量                           | 默认值                                       | 说明                                                                                                   |
| ------------------------------ | -------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| `PROMPT_DB_PATH`             | `<backend>/prompt_manager.db`              | SQLite 路径，主服务 / Agent 共享同一文件                                                               |
| `PROMPT_MANAGER_URL`         | `http://localhost:8900`                    | Agent 拉取 LLM 配置的主服务地址                                                                        |
| `FLOW_DATA_DIR`              | `<backend>/flow_data`                      | 上传文件落盘目录                                                                                       |
| `DIALOGUE_FLOW_PARSER_SKILL` | `~/.codebuddy/skills/dialogue-flow-parser` | OCR skill 根路径；缺失时自动降级到内置 rapidocr                                                        |
| `LLM_API_LOG_DIR`            | `<flow_data>/api_logs`                     | LLM API 调用日志目录                                                                                   |
| `OCR_PYTHON`                 | 无                                           | 显式指定跑 OCR 的 Python 解释器（需装`rapidocr_onnxruntime`），例如 `/data/miniconda3/bin/python3` |

> 已移除 `PROMPT_MANAGER_TOKEN` / `PROMPT_MANAGER_USER` / `PROMPT_MANAGER_PASS` —— SDK 现在只调公开端点，无需鉴权。

---

## 15. 前端界面速览

主前端（Vue 3 单文件 + 本地 vue.runtime）在 `frontend/index.html`：

- 登录页 → 主管理台。头部：用户名（含 `高级权限`/`普通权限`+ 管理科室数提示）/ 科室 / 平台 / 场景 / 关键词筛选，右上角齿轮进入 LLM 配置。
- 模式切换：**提示词管理 / 知识库管理 / 流程树管理 / 账户权限**，按登录账号权限动态显示。
- 提示词管理：
  - 列表：版本、启用、标签、描述摘要。
  - 详情查看态：基本元数据 → 描述/标签 → **机器人配置看板**（按当前提示词科室+平台过滤；显示「提示词版本」列） → 提示词内容 → 变量标记映射 → 版本历史。
  - 编辑态：编辑表单中"提示词内容"上方始终显示机器人配置看板（无数据时显示空态行 + 「+ 新增条目」）；可以行内编辑/删除并立即生效。
- 知识库管理：11 类知识标签 + `bot_id` 双维度筛选；右侧详情卡顶部新增「导出 / 导入」按钮，按当前筛选下载/上传 Excel；新增/删除知识库按钮并排。
- 流程树管理：上传解析、缩略图预览、自然语言描述编辑、重新解析、跨库搜索。
- 账户管理：admin 专用；按提示词/知识库/流程树三大模块颗粒到查看/编辑/删除；增加「管理科室」多选编辑。

Agent 前端 `agent_frontend/`：

- 左侧「流程树图库」：按科室 / 平台 / 关键词跨库搜索，缩略图卡片。
- 右侧：
  - 「流程树解析」：图片预览、描述编辑、重新解析、删除。
  - 「LLM 对话」：直连 `/api/chat` 与激活模型对话。

---

## 16. 常见问题

**Q: 解析流程图报「未提供图片」？**

- 说明当前 LLM 不支持视觉输入。系统会自动降级到 OCR + 文本 chat，只要环境装了 `rapidocr_onnxruntime` 就能拿到自然语言描述。
- 想要更精细的图形理解，请激活视觉模型（`qwen-vl-max` / `gpt-4o` 等）。

**Q: 服务启动了但页面卡在「正在检查登录状态」？**

- 浏览器缓存旧 HTML 是最常见原因，已加 `Cache-Control: no-store` 头，**强刷**（`Ctrl+F5`）即可。
- 主前端如需完全脱离外网 CDN，可将 Vue 运行时放到 `frontend/vendor/vue.global.prod.js` 并把 `<script src>` 改为本地路径（已默认就绪）。

**Q: SDK 拿到的提示词版本没更新？**

- 确认 `client.start_auto_update(interval=30)` 已启动。
- 或调用 `client.preload()` 主动强制同步。
- 切换 LLM 版本时，SDK 内部 `VisionCapabilityCache` 会清空，无需手动。

**Q: 提示词/知识库更新了但 qwen 服务看到的还是旧版本？**

- `get_resolved` 缓存 key 已包含 `extra_variables`，但若仍命中旧缓存，请确认：
  1. SDK 处于 `preload()` 或 `start_auto_update()` 状态。
  2. qwen 服务有注册 `on_update(self._on_prompt_manager_update)` 回调（默认已加）。
  3. 提示词版本号有提升（知识库变更不会自动升 version，所以知识库更新走 `kb:` 回调路径）。

**Q: 想加自定义占位符？**

- 提示词内容里写 `{我的占位符}`，然后在管理页「变量映射」里把变量名映射到 `{我的占位符}`；调用 `resolve` 时通过 `extra_variables` 传值即可。

**Q: 部署环境 Python 里没装 rapidocr，OCR 兜底也失败？**

- 方案 1：在 Agent 服务运行环境执行 `pip install rapidocr_onnxruntime`。
- 方案 2：设置环境变量 `OCR_PYTHON=/data/miniconda3/bin/python3` 指定已装 rapidocr 的解释器，`flow_parser_service` 会通过子进程调用。

**Q: 普通用户管理范围外的数据为什么看得到？**

- 检查账号的 `managed_departments` 字段是否配置（不要为空数组），且**重新登录**（token 中的 user 字段已缓存）。
- 列表自动过滤仅对 `/api/prompts`、`/api/knowledge`、`/api/flow_trees` 生效；单条详情接口未做过滤（因为管理范围外拿不到 ID）。

---

## 17. 技术栈

- **后端**：FastAPI + SQLite（WAL 模式）+ Pydantic v2 + openpyxl（知识库导入导出）
- **前端**：Vue 3（本地 `vue.global.prod.js`，零构建）
- **流程树解析**：`dialogue-flow-parser` skill（OCR）+ `rapidocr_onnxruntime` 兜底 + OpenAI 兼容多模态 LLM
- **PDF 转图**：PyMuPDF（`fitz`）优先，`pdf2image` 兜底，200 DPI
- **客户端 SDK**：仅依赖 Python 标准库，可选 `websocket-client`（热更新）/ `sentence-transformers` + `numpy`（语义检索）
- **知识库检索**：倒排索引 + TF-IDF 加权余弦；`heapq.nlargest` / `np.argpartition` 取 TopK；停用词降噪；语义向量预 L2 归一化
- **认证**：token 存 `auth_sessions` 表，30 天过期；服务启动时清空；中间件白名单公开 `/api/v1/*`、`/api/meta/*`、`/api/auth/login`、`/api/settings/*`

---

## 18. 相关文档

| 文档                       | 说明                                                              |
| -------------------------- | ----------------------------------------------------------------- |
| `README.md`              | 本文件：架构 / API / SDK / 部署（面向开发）                        |
| `操作手册.md`             | 页面配置操作手册：逐页操作步骤 + 字段说明（面向运营 / 业务方）      |
| `AGENT_ARCHITECTURE.md`  | Agent 架构设计：当前架构判定 + 业界方案对比 + 演进路线              |
